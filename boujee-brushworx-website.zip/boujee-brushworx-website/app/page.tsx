import Link from 'next/link'

const services = [
  ['Interior Painting', 'Detailed preparation, premium Dulux finishes and clean execution for high-end interiors.'],
  ['Exterior Painting', 'Weather-aware coating systems for homes across Victoria.'],
  ['Decorative Finishes', 'Feature walls, French wash effects and refined statement finishes.'],
  ['Project Specification', 'Clear scope, materials, conditions, communication and payment terms before work begins.']
]

const faqs = [
  ['What makes Boujee Brush-worx different?', 'We focus on preparation, detail, premium coating systems and clear project communication.'],
  ['Do you use Dulux products?', 'Yes. Dulux products are commonly specified because they suit premium residential and commercial repainting systems.'],
  ['Do you provide estimates?', 'Yes. Estimates can include scope, materials, labour, exclusions, conditions and optional project documentation.']
]

export default function Home() {
  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } }))
  }

  return (
    <main>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <section className="mx-auto grid max-w-7xl gap-10 px-5 py-24 md:grid-cols-[1.2fr_.8fr] md:items-center">
        <div>
          <p className="mb-4 text-sm uppercase tracking-[0.35em] text-boujeeGold">Premium Painting Victoria</p>
          <h1 className="max-w-4xl text-5xl font-black leading-tight md:text-7xl">High-end painting with <span className="gold-gradient">detail, structure and finish</span>.</h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-boujeeCream/75">Boujee Brush-worx delivers premium interior, exterior and decorative painting services across the Yarra Valley, Yarra Ranges, Melbourne and Victoria.</p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link href="/estimate-request" className="rounded-full bg-boujeeGold px-6 py-3 font-bold text-black">Request an Estimate</Link>
            <Link href="/knowledge-centre" className="rounded-full border border-boujeeGold/40 px-6 py-3 font-bold text-boujeeGold">Explore Knowledge Centre</Link>
          </div>
        </div>
        <div className="lux-card p-8">
          <h2 className="text-2xl font-bold text-boujeeGold">Built for AI search</h2>
          <p className="mt-4 leading-7 text-boujeeCream/70">This website includes structured data, FAQ content, location signals, service pages, sitemap and knowledge-centre architecture so search engines and AI assistants can understand what Boujee Brush-worx does.</p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16">
        <h2 className="mb-8 text-3xl font-bold">Services</h2>
        <div className="grid gap-5 md:grid-cols-4">
          {services.map(([title, text]) => <div key={title} className="lux-card p-6"><h3 className="text-xl font-bold text-boujeeGold">{title}</h3><p className="mt-3 text-boujeeCream/70">{text}</p></div>)}
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-5 py-16">
        <h2 className="mb-8 text-3xl font-bold">Common questions</h2>
        <div className="space-y-4">{faqs.map(([q,a]) => <details key={q} className="lux-card p-5"><summary className="cursor-pointer font-bold text-boujeeGold">{q}</summary><p className="mt-3 text-boujeeCream/70">{a}</p></details>)}</div>
      </section>
    </main>
  )
}
