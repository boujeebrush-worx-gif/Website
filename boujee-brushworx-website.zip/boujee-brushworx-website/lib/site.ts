export const site = {
  name: 'Boujee Brush-worx',
  url: 'https://www.boujeebrushworx.com.au',
  description: 'Premium residential and commercial painting services across Victoria, with detailed preparation, Dulux systems and high-end finishes.',
  areaServed: ['Yarra Valley', 'Yarra Ranges', 'Melbourne', 'Victoria'],
  phone: '',
  email: '',
  owner: 'Max Greenwood'
}
