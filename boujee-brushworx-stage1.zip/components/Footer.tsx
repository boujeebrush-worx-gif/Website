export default function Footer() {
  return (
    <footer className="border-t border-boujeeGold/20 px-5 py-10 text-center text-sm text-boujeeCream/60">
      <p>© {new Date().getFullYear()} Boujee Brush-worx. Premium painting, preparation and finishes across Victoria.</p>
    </footer>
  )
}
