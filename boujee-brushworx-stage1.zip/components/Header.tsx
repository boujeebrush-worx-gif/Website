import Link from 'next/link'

export default function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-boujeeGold/20 bg-boujeeBlack/85 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <Link href="/" className="text-lg font-bold tracking-[0.18em] text-boujeeCream">BOUJEE <span className="text-boujeeGold">BRUSH-WORX</span></Link>
        <nav className="hidden gap-7 text-sm text-boujeeCream/80 md:flex">
          <Link href="/services/interior-painting">Interior</Link>
          <Link href="/services/exterior-painting">Exterior</Link>
          <Link href="/knowledge-centre">Knowledge</Link>
          <Link href="/estimate-request">Estimate</Link>
          <Link href="/contact">Contact</Link>
        </nav>
      </div>
    </header>
  )
}
