import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        boujeeBlack: '#080808',
        boujeeGold: '#C6A15B',
        boujeeCream: '#F7F1E8'
      }
    }
  },
  plugins: []
}
export default config
