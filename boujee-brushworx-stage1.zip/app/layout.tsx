import type { Metadata } from 'next'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { site } from '@/lib/site'

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: 'Boujee Brush-worx | Premium Painting Victoria',
    template: '%s | Boujee Brush-worx'
  },
  description: site.description,
  openGraph: {
    title: 'Boujee Brush-worx',
    description: site.description,
    url: site.url,
    siteName: site.name,
    locale: 'en_AU',
    type: 'website'
  },
  robots: { index: true, follow: true }
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    name: site.name,
    url: site.url,
    description: site.description,
    founder: site.owner,
    areaServed: site.areaServed,
    serviceType: ['Interior Painting', 'Exterior Painting', 'Decorative Finishes', 'Residential Painting', 'Commercial Painting'],
    knowsAbout: ['Dulux paint systems', 'premium painting', 'surface preparation', 'heritage repainting', 'interior painting', 'exterior painting']
  }

  return (
    <html lang="en-AU">
      <body>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  )
}
