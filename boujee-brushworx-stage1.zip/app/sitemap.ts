import { MetadataRoute } from 'next'
import { site } from '@/lib/site'
export default function sitemap(): MetadataRoute.Sitemap {
  return ['', '/services/interior-painting', '/services/exterior-painting', '/knowledge-centre', '/estimate-request', '/contact'].map(path => ({ url: `${site.url}${path}`, lastModified: new Date(), changeFrequency: 'monthly', priority: path === '' ? 1 : .8 }))
}
