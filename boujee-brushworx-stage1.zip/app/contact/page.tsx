import { site } from '@/lib/site'
export const metadata = { title: 'Contact', description: 'Contact Boujee Brush-worx for premium painting services.' }
export default function Page(){return <main className="mx-auto max-w-4xl px-5 py-20"><h1 className="text-5xl font-black">Contact</h1><p className="mt-6 text-boujeeCream/75">Ready to discuss a premium painting project?</p><div className="lux-card mt-8 p-6"><p>Email: {site.email}</p><p>Phone: {site.phone}</p><p>Service areas: Yarra Valley, Eastern Suburbs and Gippsland.</p></div></main>}
