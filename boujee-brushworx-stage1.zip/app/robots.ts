import { MetadataRoute } from 'next'
import { site } from '@/lib/site'
export default function robots(): MetadataRoute.Robots { return { rules: { userAgent: '*', allow: '/', disallow: ['/staff/'] }, sitemap: `${site.url}/sitemap.xml` } }
