export const site = {
  name: 'Boujee Brush-worx',
  url: 'https://www.boujeebrush-worx.com.au',
  description: 'Premium residential and commercial painting services across the Yarra Valley, Eastern Suburbs and Gippsland, with detailed preparation, Dulux systems and high-end finishes.',
  areaServed: ['Yarra Valley', 'Eastern Suburbs', 'Gippsland'],
  phone: '0434 551 252',
  email: 'Boujeebrush-worx@outlook.com',
  owner: 'Max Greenwood'
}
